These tools are used in the build process. Placing them in this tools directory prevents GitHub from including them in language detection.
